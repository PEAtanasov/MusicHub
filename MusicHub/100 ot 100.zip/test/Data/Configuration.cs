﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-8NR9GDQ\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
